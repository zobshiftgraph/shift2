SHIFT GRAPH CONNECTOR — INSTALL INSTRUCTIONS
=============================================

1. Open Edge and go to: edge://extensions/
2. Turn ON "Developer mode" (toggle in bottom-left)
3. Click "Load unpacked"
4. Select this folder (shift-graph-extension)
5. The Shift Graph icon will appear in your toolbar

HOW TO USE
----------
1. Log into wmtscheduler.faa.gov
2. Navigate to a day's Worksheet View
3. Click the Shift Graph toolbar icon
4. Click "Send to Shift Graph"
5. Open (or switch to) your Shift Graph HTML file
   — it will automatically load the new data

NOTES
-----
- The extension only reads data, never writes anything to WMT
- Data is stored locally in your browser (chrome.storage.local)
- Shift Graph checks for new data every time it loads or gains focus
- You can send multiple days one at a time
